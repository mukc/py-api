1. Add authentication
2. Add pagination
3. Filtering search