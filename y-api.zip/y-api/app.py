from quart import Quart
from src.reviews.reviews import blueprint as review_blueprint
import asyncpg
import yaml
import logging

''' DB Parameters '''
DB_CONFIG_PATH = 'config/db_config.yml'
with open(DB_CONFIG_PATH, 'r') as f:
    config = yaml.safe_load(f)
host = config['DB_HOST']
name = config['DB_NAME']
user = config['DB_USER']
password = config['DB_PASS']
port = 5432


def create_app():
    app = Quart(__name__)

    logger = logging.getLogger('werkzeug')
    handler = logging.FileHandler('reviews.log')
    app.logger.addHandler(handler)
    app.logger.setLevel(logging.DEBUG)

    @app.before_first_request
    async def create_db():
        dsn = 'postgres://{0}:{1}@{2}:{3}/{4}'.format(user, password, host, port, name)
        app.pool = await asyncpg.create_pool(dsn, min_size=1, max_size=3)


    @app.route('/')
    async def hello():
        app.logger.info('Hello from Yogi App')
        return 'Hello from Yogi App'

    app.register_blueprint(review_blueprint, url_prefix='/yogi')

    return app


yogi_app = create_app()

if __name__ == '__main__':
    # app.run()
    create_app().run(debug=True)
