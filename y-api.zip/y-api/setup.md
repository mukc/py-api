1. Go to project directory and run the following command to install dependencies

   ```pip install -r requirement.txt```

2. To start the project run 'python app.py'