import yaml
from quart import Blueprint, request, jsonify, current_app

blueprint = Blueprint('reviews', __name__)

''' Retrieve SQL queries'''
REVIEW_SQL_PATH = 'queries/reviews_sql.yml'
with open(REVIEW_SQL_PATH, 'r') as f:
    review_sql = yaml.safe_load(f)


@blueprint.route('/reviews')
async def get_reviews():

    brands_query = review_sql['BRAND_QUERY']
    current_app.logger.info('Fetching brands query from SQL file..')
    brands_data = await get_data(brands_query)
    current_app.logger.info('Fetched Brands data.. Next fetching Products')
    products_query = review_sql['PRODUCTS_QUERY']
    products_data = await get_data(products_query)

    ''' Format the data'''

    return jsonify({'type': 'Brands', 'items': brands_data if brands_data else []}, {'type': 'Products', 'items': products_data if products_data else []})


'''
Method to retrieve data from DB
'''


async def get_data(query, args=()):
    results = []
    try:
        async with current_app.pool.acquire() as connection:
            async with connection.transaction():
                async for result in connection.cursor(query):
                    results.append(dict(result))
        current_app.logger.info('Successfully fetched data')
        # current_app.logger.debug('Debug Mode: Success')
        return results
    except Exception as e:
        print(e)
        current_app.logger.error(e)

# generalize the data columns in response